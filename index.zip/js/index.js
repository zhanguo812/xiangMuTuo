$(() => {
  // biao1();
  // biao2();
  // biao3();
  //事件委托  点击一个事件  切换一个div
  let gongzuoClick = () => {
    $('#daibanshixiang').on("click", "span", function () {
      $(this).addClass('active_1').siblings(".active").removeClass("active_1 display")
      $("#" + $(this).attr("div_obj")).css("display", "block").siblings(".table-shixiang").css("display",
        "none");
    });
  }
  let rili = (i) => {
    if (i) {
      $("#rili").css("display", "block");
    } else {
      a("rili");
    }
  }
  let email = (i) => {
    if (i) {
      $("#email").css("display", "block");
    } else {
      a("email");
    }
  }
  let main = (i) => {
    if (i) {
      $("#main").css("display", "block");
    } else {
      a("main");
    }
  }
  let xinwen = (i) => {
    if (i) {
      $("#xinwen").css("display", "block");
    } else {
      a("xinwen");
    }
  }
  let gongzuo = (i) => {
    if (i) {
      $("#div1").css("display", "block");
      gongzuoClick();
    } else {
      a("div1");
    }
  }

  let a = (j) => {
    i = "javascript:;";
    let a = $("<a href></a>");
    a.href = i;
    a.html("(请设置主页)");
    $("#" + j).prev().append(a);
  }
  let mubanAdd = (i, title, j) => {
    let muban = $(`
    <div class="index-content" i="${i}" id="biao${j}">
    <div class="index-content-header">
      <span>${title}</span>
      <span style="clear: both;"></span>
    </div>
  </div>
    `)
    let munban = muban.appendTo($("#index"));
    if (muban.attr("i") % 2 == 0) {
      muban.css("margin-left", "15px");
    }
  }
  let container = (i, j) => {
    var div = $(`
    <div id="container${i}" style="height: 85%;width: 100%;"></div>
    `);
    let a = $("<a href></a>");
    a.href = "javascript:;";
    a.html("(请设置主页)");
    if (j == true) {
      div.appendTo($("#biao" + i));
      biao(i);
    } else {
      $("#biao" + i).children(":first-child").append(a);
    }
  }
  rili(true);//日历模块
  email(true);//未读邮件模块
  main(false);//企业资讯模块
  xinwen(true);//新闻模块
  gongzuo(true);//工作模块
  //------------------------------------添加模块
  //参数i：添加的模块编号 从1开始  数量表示当前添加的模块是奇数还是偶数
  //title:标题  模块的标题
  //id:biao的id值，id值从数字5开始；id值关联渲染的查找
  mubanAdd(1, "图1", 5);
  mubanAdd(2, "图2", 6);
  mubanAdd(3, "图3", 7);
  mubanAdd(4, "图4", 8);
  mubanAdd(5, "图4", 9);
  mubanAdd(6, "图4", 10);
  //------------------------控制图表模块的显示
  //参数i:图表编号，参数j: true显示 false 不显示
  container(1, false);
  container(2, true);
  container(3, false);
  container(4, true);

  container(5, false);
  container(6, false);
  container(7, false);
  container(8, false);
  container(9, false);
  container(10, false);
})